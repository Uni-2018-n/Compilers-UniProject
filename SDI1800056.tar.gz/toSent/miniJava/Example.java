class Example {
    public static void main(String[] args) {
        int a;
        a = 3;
    }
}

class A {
    public int fooo(int i, int j, A a1) {
        boolean d;
        d = (new boolean[3])[3];
        // c=a.fooo(i,j);

        return i + ((i * j) + (this.fooo(i, j, a1)));
    }



    public boolean bar(int k, int d) {
        int p;
        return false;
    }
}

class B extends A {
    int i;
    int k;


}

class C {
    int i;
    B b;
    boolean d;
    int k;
    A a;


    public int test(int i, int j) {
        i = 1;
        return 2;
    }
}

